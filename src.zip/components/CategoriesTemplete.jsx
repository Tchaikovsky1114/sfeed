import React from 'react';
import CategoriesTempleteView from './CategoriesTempleteView';

const CategoriesTemplete = ({categoryHeadlineNews,categories}) => {
  
  const {articles,totalResults} = categoryHeadlineNews;
  
  return <CategoriesTempleteView categories={categories} articles={articles} totalResults={totalResults} />;
};

export default CategoriesTemplete;