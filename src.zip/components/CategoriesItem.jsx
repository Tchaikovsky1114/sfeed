import React from 'react';
import CategoriesItemView from './CategoriesItemView';

const CategoriesItem = ({article}) => {
  return <CategoriesItemView article={article} />
};

export default CategoriesItem;