import React, { useContext } from 'react';
import { HeadlineContext } from '../store/HeadlineContext';

const Article = () => {

  return (
    <div>
     
    </div>
  );
};

export default Article;