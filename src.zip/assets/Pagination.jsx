
import uuid from "react-uuid"
export default function Pagination({totalResults,articles,categories}) {
  const pageNumber = Math.ceil(totalResults / articles.length)
  return (
    <div className="bg-slate-500 px-4 py-3 flex items-center justify-between rounded-md sm:px-6">
      <div className="flex justify-between  sm:hidden ">
        <button
          href="#"
          className="relative inline-flex items-center shrink px-2 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
        >
          Previous
        </button>
        <button
          href="#"
          className="ml-3 relative inline-flex items-center px-5 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
        >
          Next
        </button>
      </div>
      <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
        <div>
          <p className="text-sm text-primary pr-4">
            Showing <span className="font-medium">1</span> to <span className="font-medium">10</span> of{' '}
            <span className="font-medium">{totalResults}</span> results
          </p>
        </div>
        <div>
          <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
            <button
              href="#"
              className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
            >
              <span className="sr-only">Previous</span>
              <div className="h-5 w-5 font-bold" aria-hidden="true">←</div>
            </button>
            {/* Current: "z-10 bg-indigo-50 border-indigo-500 text-indigo-600", Default: "bg-white border-gray-300 text-gray-500 hover:bg-gray-50" */}
            {Array(pageNumber).fill().map((_,i) =>(<button
              key={uuid()}
              href="#"
              aria-current="page"
              className="z-10 bg-primary border-slate-300 text-primary relative inline-flex items-center px-4 py-2 border text-sm font-medium"
            >
              {i + 1}
            </button>))}
           
            <button
              href="#"
              className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
            >
              <span className="sr-only">Next</span>
              <div className="h-5 w-5 font-bold" aria-hidden="true">→</div>
            </button>
          </nav>
        </div>
      </div>
    </div>
  )
}