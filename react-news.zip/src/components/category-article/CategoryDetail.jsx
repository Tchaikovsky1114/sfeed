import React from 'react';
import CategoryDetailView from './CategoryDetailView';

const CategoryDetail = ({article}) => {
  return <CategoryDetailView article={article} />
};

export default CategoryDetail;