import React from 'react';

const Banner = () => {
  return (
    
      <div>TODAY'S HEADLINE</div>
    
  );
};

export default Banner;